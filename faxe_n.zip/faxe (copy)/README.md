faxe
=====

Faxe tries to be a timeseries stream and batch processor on top of the [dataflow](https://github.com/heyoka/dataflow)
and [dfs](https://github.com/heyoka/dfs) applications.

This project started out as a [influxdata/kapacitor](https://github.com/influxdata/kapacitor) clone in erlang, but fully cluster-aware.


    
More soon

Build
-----

faxe is a rebar3 release

    $ rebar3 compile


Erlang
------
    >= 19