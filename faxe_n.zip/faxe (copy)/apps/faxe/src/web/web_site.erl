%% Date: 05.11.17 - 21:57
%% Ⓒ 2017 LineMetrics GmbH
-module(web_site).
-author("Alexander Minichmair").

%% API
-export([]).

-behavior(erlydtl_library).
