# from kapacitor.udf.agent import Agent, Handler, Server
# from kapacitor.udf import udf_pb2
# import signal
import erlport.erlterms

# import logging
# logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s:%(name)s: %(message)s')
# logger = logging.getLogger()


# Mirrors all points it receives back to faxe
class Mirror:

    @staticmethod
    def info():
        print("info called")
        li = erlport.erlterms.List([(erlport.erlterms.Atom(b"foo"), erlport.erlterms.Atom(b"string"))])
        return li

    def init(self, init_req=None):
        print("hey you called init ?!")
        ret = {"eins": erlport.erlterms.List([1, 2, 3, 4]), "zwei": 2, "drei": {"view": 3}}
        return erlport.erlterms.Map(ret)

    def batch(self, req):
        return req

    def point(self, req):
        return req

# class accepter(object):
#     _count = 0
#     def accept(self, conn, addr):
#         self._count += 1
#         a = Agent(conn, conn)
#         h = MirrorHandler(a)
#         a.handler = h
#
#         logger.info("Starting Agent for connection %d", self._count)
#         a.start()
#         a.wait()
#         logger.info("Agent finished connection %d",self._count)

# if __name__ == '__main__':
#     path = "/tmp/mirror.sock"
#     if len(sys.argv) == 2:
#         path = sys.argv[1]
#     server = Server(path, accepter())
#     logger.info("Started server")
#     server.serve()

