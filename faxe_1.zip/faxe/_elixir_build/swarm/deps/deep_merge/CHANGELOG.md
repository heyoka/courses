## 0.1.1 (November 29, 2016)

* Remove warnings when run with elixir 1.4.0-rc.0
