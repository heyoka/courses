%% Date: 18.04.18 - 19:31
%% Ⓒ 2018 heyoka
-module(faxe_peer_manager).
-author("Alexander Minichmair").

-behaviour(gen_server).

%% API
-export([start_link/0, join/1, leave/1, get_node_list/1, get_node/0, node_info/0]).

%% gen_server callbacks
-export([init/1,
   handle_call/3,
   handle_cast/2,
   handle_info/2,
   terminate/2,
   code_change/3]).

-define(SERVER, ?MODULE).
-define(SYNC_INTERVAL, 15*1000).

-record(state, {nodes = [], up_nodes = []}).

%%%===================================================================
%%% API
%%%===================================================================

%% join a node to the cluster
join(Node) when is_atom(Node) ->
   gen_server:call(?MODULE, {join, Node}).

%% remove a node from the cluster
leave(Node) when is_atom(Node) ->
   gen_server:call(?MODULE, {leave, Node}).

%% get one node from the list of up_nodes
%% @see node_list
get_node() ->
   get_node_list(1).

%% @doc
%% get a list of cluster nodes (Quorum length), which are able to handle a processing task
%% the returned nodes will be sorted by their processe-count
%% (erlang:system_info(process_count))
%%
-spec get_node_list(non_neg_integer()) -> list(atom()).
get_node_list(Quorum) ->
   gen_server:call(?SERVER, {node_list, Quorum}).

%%--------------------------------------------------------------------
%% @doc
%% Starts the server
%%
%% @end
%%--------------------------------------------------------------------
-spec(start_link() ->
   {ok, Pid :: pid()} | ignore | {error, Reason :: term()}).
start_link() ->
   gen_server:start_link({local, ?SERVER}, ?MODULE, [], []).

%%%===================================================================
%%% gen_server callbacks
%%%===================================================================

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Initializes the server
%%
%% @spec init(Args) -> {ok, State} |
%%                     {ok, State, Timeout} |
%%                     ignore |
%%                     {stop, Reason}
%% @end
%%--------------------------------------------------------------------
-spec(init(Args :: term()) ->
   {ok, State :: #state{}} | {ok, State :: #state{}, timeout() | hibernate} |
   {stop, Reason :: term()} | ignore).
init([]) ->
   erlang:start_timer(?SYNC_INTERVAL, self(), node_sync),
   {ok, #state{}}.

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Handling call messages
%%
%% @end
%%--------------------------------------------------------------------
handle_call({node_list, Length}, _From, State=#state{up_nodes = Nodes0}) ->
   Nodes = [node_info()] ++ Nodes0,
   NodesSorted = lists:sort(Nodes),
   lager:info("sorted nodes: ~p",[NodesSorted]),
   StartNodes = lists:sublist(NodesSorted, 1, Length),
   {reply, StartNodes, State};
handle_call({join, Node}, _From, State=#state{nodes = Nodes0}) ->
   monitor_node(Node, true),
   NewState = node_sync(State#state{nodes = [Node|Nodes0]}),
   {reply, ok, NewState};
handle_call({leave, Node}, _From, State=#state{nodes = Nodes0}) ->
   monitor_node(Node, false),
   NewState = node_sync(State#state{nodes = lists:delete(Node, Nodes0)}),
   {reply, ok, NewState};
handle_call(node_info, _From, State) ->
   {reply, node_info(), State};
handle_call(_Request, _From, State) ->
   {reply, ok, State}.

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Handling cast messages
%%
%% @end
%%--------------------------------------------------------------------
-spec(handle_cast(Request :: term(), State :: #state{}) ->
   {noreply, NewState :: #state{}} |
   {noreply, NewState :: #state{}, timeout() | hibernate} |
   {stop, Reason :: term(), NewState :: #state{}}).
handle_cast(_Request, State) ->
   {noreply, State}.

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Handling all non call/cast messages
%%
%% @spec handle_info(Info, State) -> {noreply, State} |
%%                                   {noreply, State, Timeout} |
%%                                   {stop, Reason, State}
%% @end
%%--------------------------------------------------------------------
-spec(handle_info(Info :: timeout() | term(), State :: #state{}) ->
   {noreply, NewState :: #state{}} |
   {noreply, NewState :: #state{}, timeout() | hibernate} |
   {stop, Reason :: term(), NewState :: #state{}}).
handle_info({nodedown, Node}, State=#state{nodes = Nodes}) ->
   NewState = node_sync(State#state{nodes = lists:delete(Node, Nodes)}),
   {noreply, NewState};
handle_info({timeout, _Ref, node_sync}, State = #state{}) ->
   {noreply, node_sync(State)}.

%%--------------------------------------------------------------------
%% @private
%% @doc
%% This function is called by a gen_server when it is about to
%% terminate. It should be the opposite of Module:init/1 and do any
%% necessary cleaning up. When it returns, the gen_server terminates
%% with Reason. The return value is ignored.
%%
%% @spec terminate(Reason, State) -> void()
%% @end
%%--------------------------------------------------------------------
-spec(terminate(Reason :: (normal | shutdown | {shutdown, term()} | term()),
    State :: #state{}) -> term()).
terminate(_Reason, _State) ->
   ok.

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Convert process state when code is changed
%%
%% @spec code_change(OldVsn, State, Extra) -> {ok, NewState}
%% @end
%%--------------------------------------------------------------------
-spec(code_change(OldVsn :: term() | {down, term()}, State :: #state{},
    Extra :: term()) ->
   {ok, NewState :: #state{}} | {error, Reason :: term()}).
code_change(_OldVsn, State, _Extra) ->
   {ok, State}.

%%%===================================================================
%%% Internal functions
%%%===================================================================
node_sync(State = #state{nodes = AllNodes}) ->
   {Responses, _BadNodes} = gen_server:multi_call(AllNodes, ?MODULE, node_info, 7000),
   State#state{up_nodes = Responses}.

node_info() ->
   {erlang:system_info(process_count), node()}.