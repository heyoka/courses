%% Date: 20.04.18 - 23:25
%% Ⓒ 2018 heyoka
-module(faxe_task).
-author("Alexander Minichmair").

%% API
-export([]).
