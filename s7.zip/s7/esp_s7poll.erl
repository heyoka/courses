%%%-------------------------------------------------------------------
%%% @author heyoka
%%% @copyright (C) 2019, <COMPANY>
%%% @doc
%%% get data from a siemens s7 plc via the snap7 library
%%%
%%% @end
%%% Created : 14. June 2019 11:32:22
%%%-------------------------------------------------------------------
-module(esp_s7poll).
-author("heyoka").

%% API
-behavior(df_component).

-include("faxe.hrl").
%% API
-export([init/3, process/3, options/0, handle_info/2, shutdown/1]).

-record(state, {
  ip,
  port,
  client,
  slot,
  rack,
  area,
  start,
  amount,
  interval,
  as,
  timer_ref,
  param_list
}).

options() -> [
  {ip, binary},
  {port, integer, 102},
  {every, binary, "1s"},
  {slot, integer, 0},
  {rack, integer, 0},

  {address_list, string_list}, %% s7 addressing, ie: DB2024,Int16.1224

  {db_number, integer, 1},
  {word_type, atom, byte}, %% one of snapclient::?WORD_TYPES
  {area, string, <<"db">>}, %% one of snapclient::?AREA_TYPES
  {start, integer}, %% start address
  {amount, integer, 1}, %% is/should be 1 normally

  {as, binary_list}].

init(_NodeId, _Ins,
    #{ip := Ip,
      port := Port,
      every := Dur,
      slot := Slot,
      rack := Rack,
      db_number := DbNumber,
      word_type := WordType,
      area := Area,
      start := Start,
      amount := Count,
      as := As} = Opts) ->

  lager:notice("++++ ~p ~ngot opts: ~p ~n",[_NodeId, Opts]),

  {ok, Client} = snapclient:start_link([]),
  snapclient:connect_to(Client, [{ip, Ip}, {slot, Slot}, {rack, Rack}]),

  ParamList = [#{area => Area, start => Start, amount => Count, db_number => DbNumber, word_type := WordType}],

  Interval = faxe_time:duration_to_ms(Dur),
  TRef = poll(Interval),
  {ok, all,
    #state{
      ip = Ip,
      port = Port,
      start = Start,
      amount = Count,
      as = As,
      start = Start,
      slot = Slot,
      rack = Rack,
      client = Client,
      area = Area,
      interval = Interval,
      timer_ref = TRef,
      param_list = ParamList}}.

process(_In, #data_batch{points = _Points} = _Batch, State = #state{}) ->
  {ok, State};
process(_Inport, #data_point{} = _Point, State = #state{}) ->
  {ok, State}.

handle_info(poll, State=#state{client = Client, interval = Interval, as = Aliases, param_list = Opts}) ->
  Res = snapclient:read_multi_vars(Client, Opts),
  OutPoint = build_point(Res, Aliases),
  lager:info("Result from snap7 polling ~p : ~p",[Opts, Res]),
  %% emit the result
  dataflow:emit(OutPoint),
  TRef = poll(Interval),
  {ok, State#state{timer_ref = TRef}};
handle_info(E, S) ->
  io:format("unexpected: ~p~n", [E]),
  {ok, S#state{}}.

shutdown(#state{client = Client, timer_ref = Timer}) ->
  catch (erlang:cancel_timer(Timer)),
  catch (snapclient:disconnect(Client)).

poll(Interval) ->
  erlang:send_after(Interval, self(), poll).


build_point(ResultList, AliasList) when is_list(ResultList), is_list(AliasList) ->
  build(#data_point{ts=faxe_time:now()}, ResultList, AliasList).

build(Point=#data_point{}, [],[]) ->
  Point;
build(Point=#data_point{}, [Res|R],[Alias|A]) ->
  NewPoint = flowdata:set_field(Point, Alias, Res),
  build(NewPoint, R, A).


build_param_list(AddressList) ->
  F = fun(Address) -> do:map(binary:split(Address, <<",">>, [trim, global])) end,
  lists:map(F, AddressList).

do_map(Area, DataAddress) ->
  ok.

